<?php
require_once("../class/PHPMailer-5.2-stable/PHPMailerAutoload.php");

#Receber variáveis
$Nome=filter_input(INPUT_POST,'nome',FILTER_SANITIZE_STRING);
$Email=filter_input(INPUT_POST,'email',FILTER_SANITIZE_STRING);
$Telefone=filter_input(INPUT_POST,'telefone',FILTER_SANITIZE_STRING);
$Mensagem=filter_input(INPUT_POST,'mensagem',FILTER_SANITIZE_STRING);

#Instanciar a nossa classe
$ObjMail = new PHPMailer;
$ObjMail->isSMTP();
$ObjMail->Host = 'smtp.gmail.com';
$ObjMail->SMTPAuth = true;
$ObjMail->Username = 'utilizador';
$ObjMail->Password = 'senha';
$ObjMail->Port = 587;
$ObjMail->setFrom($Email, $Nome);
$ObjMail->addAddress('email', 'Username');
$ObjMail->isHTML(true);
$ObjMail->Subject = 'Contato do Site';
$ObjMail->Body    = "
<strong>Contato do Site</strong><br>
Nome: $Nome <br>
Email: $Email <br>
Telefone: $Telefone <br>
Mensagem: $Mensagem <br>
";
if($ObjMail->send()) {
    echo "
    <script>
        alert('Email enviado com sucesso!');
        window.location.href='../index.php';
    </script>";
} else {
    echo "
    <script>
        alert('Houve uma falha!');
        window.location.href='../views/contacto.php';
    </script>";
}
?>