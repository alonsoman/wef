<!doctype html>
<html lang="pt-pt">


<head>
	<?php require_once ("../libraries/head.php"); ?>

    <title>WEF Veículos - Anúncios WEF Veículos</title>
    
    <meta name="description" content="A WEF veículos é uma empresa especializada na venda de veículos. Temos muitos anos de experiência na área.">
    
    <meta name="keywords" content="Anúncios WEF veículos, anúncios WEF, carros na cidade de Bragança">    
</head>




<body>
<header>
	
	<?php require_once ("../libraries/body.php"); ?>
    
    <div class="ind-banner">
    
        <picture>
            <source media="(max-width: 480px)" srcset="../images/mobile-bannersobrenos.jpg">
            <source media="(min-width: 481px) and (max-width: 768px)" srcset="../images/tablet-bannersobrenos.jpg">
            <source media="(min-width: 769px)" srcset="../images/desktop-bannersobrenos.jpg">
            <img src="../images/mobile-bannersobrenos.jpg" alt="Banner Sobre Nós - WEF Veículos" title="Banner Sobre Nós - WEF Veículos">
        </picture> 
    
    </div>

</header>

<main>

<table class="tg">
<thead>
  <tr>
    <th class="tg-nrix" colspan="2">Veículos no stand WEF</th>
  </tr>
</thead>
<tbody>
  <tr>
    <td class="tg-baqh"><img src="../images/anuncios/1.jpg"></td>
    <td class="tg-yla0"><b>Veículo 1</b><br><br>Descrição:<br><br>Preço:</td>
  </tr>
  <tr>
    <td class="tg-baqh"><img src="../images/anuncios/2.jpg"></td>
    <td class="tg-yla0"><b>Veículo 2</b><br><br>Descrição:<br><br>Preço:</td>
  </tr>
  <tr>
    <td class="tg-baqh"><img src="../images/anuncios/2.jpg"></td>
    <td class="tg-yla0"><b>Veículo 3</b><br><br>Descrição:<br>Preço:<br></td>
  </tr>
  <tr>
    <td class="tg-baqh"><img src="../images/anuncios/2.jpg"></td>
    <td class="tg-yla0"><b>Veículo 4</b><br><br>Descrição:<br>Preço:<br></td>
  </tr>
  <tr>
    <td class="tg-baqh"><img src="../images/anuncios/2.jpg"></td>
    <td class="tg-yla0"><b>Veículo 5</b><br><br>Descrição:<br>Preço:<br></td>
  </tr>
  <tr>
    <td class="tg-baqh"><img src="../images/anuncios/2.jpg"></td>
    <td class="tg-yla0"><b>Veículo 6</b><br><br>Descrição:<br>Preço:</td>
  </tr>
  <tr>
    <td class="tg-baqh"><img src="../images/anuncios/2.jpg"></td>
    <td class="tg-yla0"><b>Veículo 7</b><br><br>Descrição:<br>Preço:</td>
  </tr>
  <tr>
    <td class="tg-baqh"><img src="../images/anuncios/2.jpg"></td>
    <td class="tg-yla0"><b>Veículo 8</b><br><br>Descrição:<br>Preço:<br></td>
  </tr>
</tbody>
</table>

</main>



<footer>

	<?php require_once ("../libraries/footer.php"); ?>

</footer>

</body>


</html>