<!doctype html>
<html lang="pt-pt">


<head>
	<?php require_once ("../libraries/head.php"); ?>

    <title>WEF Veículos - Contacto WEF Veículos</title>
    
    <meta name="description" content="A WEF veículos é uma empresa especializada na venda de veículos. Temos muitos anos de experiência na área.">
    
    <meta name="keywords" content="Contacto WEF veículos, Contacto WEF, carros na cidade de Bragança">
    
</head>




<body>
<header>
	
	<?php require_once ("../libraries/body.php"); ?>
    
    <div class="ind-banner">
    
        <picture>
            <source media="(max-width: 480px)" srcset="../images/mobile-bannercontacto.jpg">
            <source media="(min-width: 481px) and (max-width: 768px)" srcset="../images/tablet-bannercontacto.jpg">
            <source media="(min-width: 769px)" srcset="../images/desktop-bannercontacto.jpg">
            <img src="../images/mobile-bannercontacto.jpg" alt="Banner Contacto - WEF Veículos" title="Banner Contacto - WEF Veículos">
        </picture> 
    
    </div>

</header>

<main>

	<div class="TextoResponsivo">

        <form name="FormularioContacto" id="FormularioContacto" method="post" action="../controllers/ControllerContacto.php">
        	<div class="Formulario">
            	<label for="nome">Nome: * </label><br/>
            	<input type="text" id="nome" name="nome" required>
            </div>
            
            <div class="Formulario">
            	<label for="email">Email: * </label><br/>
            	<input type="email" id="email" name="email" required>
            </div>
            
            <div class="Formulario">
            	<label for="telefone">Telefone: * </label><br/>
            	<input type="tel" id="telefone" name="telefone" required>
            </div>
            
            <div class="Formulario">
            	<label for="mensagem">Mensagem: * </label><br/>
            	<textarea name="mensagem" id="mensagem" required></textarea>
            </div>
            
            <div class="Formulario">
            	<input type="submit" id="botao" name="botao" value="Enviar">
            </div>
        </form>

    </div>

</main>



<footer>

	<?php require_once ("../libraries/footer.php"); ?>

</footer>

</body>


</html>