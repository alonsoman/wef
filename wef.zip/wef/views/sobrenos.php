<!doctype html>
<html lang="pt-pt">


<head>
	<?php require_once ("../libraries/head.php"); ?>

    <title>WEF Veículos - Sobre a WEF Veículos</title>
    
    <meta name="description" content="A WEF veículos é uma empresa especializada na venda de veículos. Temos muitos anos de experiência na área.">
    
    <meta name="keywords" content="Sobre a WEF veículos, about WEF, carros na cidade de Bragança">
    
</head>




<body>
<header>
	
	<?php require_once ("../libraries/body.php"); ?>
    
    <div class="ind-banner">
    
        <picture>
            <source media="(max-width: 480px)" srcset="../images/mobile-bannersobrenos.jpg">
            <source media="(min-width: 481px) and (max-width: 768px)" srcset="../images/tablet-bannersobrenos.jpg">
            <source media="(min-width: 769px)" srcset="../images/desktop-bannersobrenos.jpg">
            <img src="../images/mobile-bannersobrenos.jpg" alt="Banner Sobre Nós - WEF Veículos" title="Banner Sobre Nós - WEF Veículos">
        </picture> 
    
    </div>

</header>

<main>

	<div class="TextoResponsivo">
		
		<b>Empresa de veículos - WEF</b><br/><br/>

		A eficácia em conseguir obter os melhores preços do mercado e ter a mais diversa gama de viaturas para satisfazer todo o tipo de clientes tem sido o nosso grande êxito desde 2008.<br/><br/>
		 
		A nossa loja encontra-se em <b>Bragança</b> e conta com mais de <b>30</b> profissionais. Para maior qualidade na entrega e preparação de nossos veículos, contamos com ajuda de oficina própria com diversos funcionários qualificados no ramo automóvel.</br><br/>
		 
		TEMOS VIATURAS PRONTAS A ANDAR DESDE <b>1000€</b> COM REVISÃO E MUDANÇA DE NOME INCLUÍDA.<br/><br/> 
		 
		A compra de um veículo pode parecer fácil mas só profissionais do ramo sabem as dificuldades existentes e os cuidados a se ter. Consulte-nos e venha confirmar a segurança na compra de um veículo do <b>Grupo WEF</b>.<br/>
            
    </div>

</main>



<footer>

	<?php require_once ("../libraries/footer.php"); ?>

</footer>

</body>


</html>