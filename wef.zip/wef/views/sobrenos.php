<!doctype html>
<html lang="pt-pt">


<head>
	<?php require_once ("../libraries/head.php"); ?>

    <title>WEF Veículos - Sobre a WEF Veículos</title>
    
    <meta name="description" content="A WEF veículos é uma empresa especializada na venda de veículos. Temos muitos anos de experiência na área.">
    
    <meta name="keywords" content="Sobre a WEF veículos, about WEF, carros na cidade de Bragança">
    
</head>




<body>
<header>
	
	<?php require_once ("../libraries/body.php"); ?>
    
    <div class="ind-banner">
    
        <picture>
            <source media="(max-width: 480px)" srcset="../images/mobile-bannersobrenos.jpg">
            <source media="(min-width: 481px) and (max-width: 768px)" srcset="../images/tablet-bannersobrenos.jpg">
            <source media="(min-width: 769px)" srcset="../images/desktop-bannersobrenos.jpg">
            <img src="../images/mobile-bannersobrenos.jpg" alt="Banner Sobre Nós - WEF Veículos" title="Banner Sobre Nós - WEF Veículos">
        </picture> 
    
    </div>

</header>

<main>

	<div class="TextoResponsivo">
    	Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.<br/>
        Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.<br/>
        Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.Texto da empresa.<br/><br/>
        
        <div id="fb-root"></div><script async defer crossorigin="anonymous" src="https://connect.facebook.net/pt_PT/sdk.js#xfbml=1&version=v7.0"></script>
        <div class="fb-page" data-href="https://www.facebook.com/webdesignemfoco/" data-tabs="timeline" data-width="180" data-height="70" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/webdesignemfoco/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/webdesignemfoco/">Webdesign em Foco</a></blockquote></div>
    </div>

</main>



<footer>

	<?php require_once ("../libraries/footer.php"); ?>

</footer>

</body>


</html>