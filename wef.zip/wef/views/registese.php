<!doctype html>
<html lang="pt-pt">


<head>
	<?php require_once ("../libraries/head.php"); ?>

    <title>WEF Veículos - Sobre a WEF Veículos</title>
    
    <meta name="description" content="A WEF veículos é uma empresa especializada na venda de veículos. Temos muitos anos de experiência na área.">
    
    <meta name="keywords" content="Sobre a WEF veículos, about WEF, carros na cidade de Bragança">
    
</head>




<body>
<header>
	
	<?php require_once ("../libraries/body.php"); ?>
    
    <div class="ind-banner">
    
        <picture>
            <source media="(max-width: 480px)" srcset="../images/mobile-registese.jpg">
            <source media="(min-width: 481px) and (max-width: 768px)" srcset="../images/tablet-registese.jpg">
            <source media="(min-width: 769px)" srcset="../images/desktop-registese.jpg">
            <img src="../images/mobile-registese.jpg" alt="Banner Sobre Nós - WEF Veículos" title="Banner Sobre Nós - WEF Veículos">
        </picture> 
    
    </div>

</header>

<main>

	<div class="TextoResponsivo">
    	Registe-se para receber a nossa newsfeed e obter mais informações!<br/><br/>
        <form name="FormularioCadastro" id="FormularioRegisto" method="post" action="../controllers/ControllerInsercao.php">
        	<div class="Formulario">
            	<label for="nome">Nome: * </label><br/>
            	<input type="text" id="nome" name="nome" required>
            </div>
            
            <div class="Formulario">
            	<label for="email">Email: * </label><br/>
            	<input type="email" id="email" name="email" required>
            </div>
            
            <div class="Formulario">
            	<label for="telefone">Telefone: * </label><br/>
            	<input type="tel" id="telefone" name="telefone" required>
            </div>
            
            <div class="Formulario">
            	<label for="idade">Idade: * </label><br/>
            	<input type="text" id="idade" name="idade" required>
            </div>
            
            <div class="Formulario">
            	<input type="submit" id="botao" name="botao" value="Registar">
            </div>
        </form>
    </div>

</main>



<footer>

	<?php require_once ("../libraries/footer.php"); ?>

</footer>

</body>


</html>