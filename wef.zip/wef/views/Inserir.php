<?php

require_once("../models/ClassConexao.php");

class ClassTeste extends ClassConexao{
    public function __construct(){
        var_dump($this->Conectar());
    }
}
$ObjTeste=new ClassTeste();

?>