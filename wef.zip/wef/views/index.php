<!doctype html>
<html lang="pt-pt">


<head>
	<?php require_once ("../libraries/head.php"); ?>

    <title>WEF Veículos - Anúncio de Veículos em Bragança</title>
    
    <meta name="description" content="A WEF Veículos é uma empresa especializada em anúncios de automóveis e motos na região de Bragança. Contamos com milhares de veículos à sua disposição.">
    
    <meta name="keywords" content="WEF veículos, empresa de veículos em Bragança, anúncios de automóveis, veículos em Bragança">
    
    <script src="../libraries/jquery.cycle.lite.js"></script>
</head>




<body>
<header>
	
	<?php require_once ("../libraries/body.php"); ?>
    
    <div class="ind-slide">
    
        <picture>
            <source media="(max-width: 480px)" srcset="../images/mobile-slide1.jpg">
            <source media="(min-width: 481px) and (max-width: 768px)" srcset="../images/tablet-slide1.jpg">
            <source media="(min-width: 769px)" srcset="../images/desktop-slide1.jpg">
            <img src="../images/mobile-slide1.jpg" alt="Veículos WEF - Slide 1" title="Veículos WEF - Slide 1">
        </picture> 
        
        <picture>
            <source media="(max-width: 480px)" srcset="../images/mobile-slide2.jpg">
            <source media="(min-width: 481px) and (max-width: 768px)" srcset="../images/tablet-slide2.jpg">
            <source media="(min-width: 769px)" srcset="../images/desktop-slide2.jpg">
            <img src="../images/mobile-slide2.jpg" alt="Veículos WEF - Slide 2" title="Veículos WEF - Slide 2">
        </picture> 
        
        <picture>
            <source media="(max-width: 480px)" srcset="../images/mobile-slide3.jpg">
            <source media="(min-width: 481px) and (max-width: 768px)" srcset="../images/tablet-slide3.jpg">
            <source media="(min-width: 769px)" srcset="../images/desktop-slide3.jpg">
            <img src="../images/mobile-slide3.jpg" alt="Veículos WEF - Slide 3" title="Veículos WEF - Slide 3">
        </picture> 
    
    </div>

</header>

<main>

	<div class="ind-anuncio">
    	<div class="ind-anuncio-title">Carro 1</div>
        <div class="ind-anuncio-image"><img src="../images/anuncios/tesla-imagem.jpg" alt="Carro 1"></div>
        <div class="ind-anuncio-texto">Tesla 2015<br>Nova geração de veículos fabricados em Portugal.</div>
    </div>
    

	<div class="ind-anuncio">
    	<div class="ind-anuncio-title">Carro 1</div>
        <div class="ind-anuncio-image"><img src="../images/anuncios/tesla-imagem.jpg" alt="Carro 1"></div>
        <div class="ind-anuncio-texto">Tesla 2015<br>Nova geração de veículos fabricados em Portugal.</div>
    </div>
    

	<div class="ind-anuncio">
    	<div class="ind-anuncio-title">Carro 1</div>
        <div class="ind-anuncio-image"><img src="../images/anuncios/tesla-imagem.jpg" alt="Carro 1"></div>
        <div class="ind-anuncio-texto">Tesla 2015<br>Nova geração de veículos fabricados em Portugal.</div>
    </div>
    

	<div class="ind-anuncio">
    	<div class="ind-anuncio-title">Carro 1</div>
        <div class="ind-anuncio-image"><img src="../images/anuncios/tesla-imagem.jpg" alt="Carro 1"></div>
        <div class="ind-anuncio-texto">Tesla 2015<br>Nova geração de veículos fabricados em Portugal.</div>
    </div>
    

	<div class="ind-anuncio">
    	<div class="ind-anuncio-title">Carro 1</div>
        <div class="ind-anuncio-image"><img src="../images/anuncios/tesla-imagem.jpg" alt="Carro 1"></div>
        <div class="ind-anuncio-texto">Tesla 2015<br>Nova geração de veículos fabricados em Portugal.</div>
    </div>
    
    

	<div class="ind-anuncio">
    	<div class="ind-anuncio-title">Carro 1</div>
        <div class="ind-anuncio-image"><img src="../images/anuncios/tesla-imagem.jpg" alt="Carro 1"></div>
        <div class="ind-anuncio-texto">Tesla 2015<br>Nova geração de veículos fabricados em Portugal.</div>
    </div>                    


	<div class="ind-anuncio">
    	<div class="ind-anuncio-title">Carro 1</div>
        <div class="ind-anuncio-image"><img src="../images/anuncios/tesla-imagem.jpg" alt="Carro 1"></div>
        <div class="ind-anuncio-texto">Tesla 2015<br>Nova geração de veículos fabricados em Portugal.</div>
    </div>
    

	<div class="ind-anuncio">
    	<div class="ind-anuncio-title">Carro 1</div>
        <div class="ind-anuncio-image"><img src="../images/anuncios/tesla-imagem.jpg" alt="Carro 1"></div>
        <div class="ind-anuncio-texto">Tesla 2015<br>Nova geração de veículos fabricados em Portugal.</div>
    </div>    

</main>



<footer>

	<?php require_once ("../libraries/footer.php"); ?>

</footer>

</body>









</html>