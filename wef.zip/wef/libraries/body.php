<div class="ind-topo"></div>
    
<nav>
   	<ul>
    	<li><a href="index">Home</a></li>
		<li><a href="sobrenos">Sobre Nós</a></li>
        <li><a href="anuncios">Anúncios</a></li>
        <li><a href="contacto">Contacto</a></li>
        <li><a href="registese">Registe-se</a></li>
    </ul>
</nav>
    
    
<div class="ind-botao">
    <img src="../images/botao.png" alt="Botão Mobile" title="Botão Mobile">
</div>
    
<div class="ind-logo">
	<picture>
        <source media="(max-width: 480px)" srcset="../images/mobile-logo.png">
        <source media="(min-width: 481px) and (max-width: 768px)" srcset="../images/mobile-logo.png">
        <source media="(min-width: 769px)" srcset="../images/desktop-logo.png">
        <img src="../images/mobile-logo.png" alt="Logótipo WEF Veículos" title="Logótipo WEF Veículos">
	</picture>
</div>
