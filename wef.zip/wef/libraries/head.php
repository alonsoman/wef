<meta charset="utf-8">

<meta name="author" content="Ricardo Moreira">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="icon" href="../images/favicon.ico">

<link rel="stylesheet" href="../libraries/stylesheet.css">

<script src="../libraries/jquery-2.1.4.min.js"></script>

<script src="../libraries/javascript.js"></script>

<script src="../libraries/jquery.maskedinput.js"></script>