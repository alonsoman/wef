<div class="Footer">
	<div class="FooterTexto">
    	Rua dos Inconfidentes, 1220 - B. Floresta <br/>
        Bragança / Portugal <br/>
        Contacto: (+351) 273327963
    </div>
    <div class="FooterImage">
    	<picture>
            <source media="(max-width: 480px)" srcset="../images/LogotipoFooterMobile.png">
            <source media="(min-width: 481px) and (max-width: 768px)" srcset="../images/LogotipoFooterMobile.png">
            <source media="(min-width: 769px)" srcset="../images/LogotipoFooter.png">
            <img src="../images/LogotipoFooterMobile.png" alt="Logotipo do Developer" title="Logotipo do Developer">
        </picture>
    </div>
</div>